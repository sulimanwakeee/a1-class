/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 *
 * @author star
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Label label;

    @FXML
    private JFXTextField user;

    @FXML
    private JFXPasswordField password;

    @FXML
    private JFXButton login;
        
    @FXML
    private JFXButton signup;

   @FXML
    private Label error;
    
    
    @FXML
    void makeLogin(ActionEvent event) {
    String user1 = user.getText();
    String pass = password.getText();
                
        if(user1.equals("ali")&&pass.equals("123")){
            javax.swing.JOptionPane.showMessageDialog(null, "Welcome Dear : "+user1);
        
    }else{
         javax.swing.JOptionPane.showMessageDialog(null, "Wrong Username Or password Please Try Again!");
        }
    }
    @Override
    public void initialize(URL url,  ResourceBundle rb) {
       
        
        
    }
   
    
    @FXML
    void Logme(ActionEvent event) {
      
        String user1 = user.getText();
    String pass = password.getText();
        Connection conn;
        PreparedStatement ps;
        
        
      try {
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root", "");
         ps = conn.prepareStatement("SELECT username, password FROM users WHERE username = '"+user1+"' and password = '"+pass+"' ");
          ResultSet result = ps.executeQuery();
          if(result.next()){
             
              error.setText("Succesfully Login!");
              
             
     
          }else{
               error.setText("Please Try Again!");
          }
        }catch(Exception e)
      {
      }
       
       
    }
    
    }
    
    
    
